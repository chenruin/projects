from django import forms
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from django.contrib.auth.models import User
from .models import *

class Registration(UserCreationForm):
    email = forms.EmailField(max_length=254,)
    fullname = forms.CharField(max_length=50, required=False, help_text='Optional.')
    address = forms.CharField(max_length=50, required=False, help_text='Optional.')
    phone = forms.CharField(max_length=15, required=False, help_text='Optional.')

    class Meta:
        model = Customer
        fields = ('username', 'email', 'password1', 'password2', 'fullname', 'address', 'phone')

class Login(forms.Form):
    username = forms.CharField(label='Username', required=True)
    password = forms.CharField(label='Password', widget=forms.PasswordInput, required=True)

class Payment(forms.Form):
    card_number = forms.CharField(
        label='Card Number',
        required=True,
        min_length=16,
        max_length=16,
        widget=forms.TextInput(attrs={'placeholder': '1234 5678 9012 3456', 'type': 'text', 'pattern': '[0-9]{16}'}),
    )

    expiration_date = forms.CharField(
        label='Expiration Date',
        required=True,
        widget=forms.TextInput(attrs={'placeholder': 'MM/YYYY', 'type': 'text', 'pattern': '(0[1-9]|1[0-2])/(20[2-9][0-9])'}),
    )

    cvv = forms.CharField(
        label='CVV',
        max_length=3,
        widget=forms.TextInput(attrs={'placeholder': '123', 'type': 'text', 'pattern': '[0-9]{3}'}),
        required=True,
    )

    card_holder = forms.CharField(
        label='Card Holder Name',
        required=True,
        widget=forms.TextInput(attrs={'type': 'text'}),
    )

class UpdateInfoForm(UserChangeForm):
    fullname = forms.CharField(max_length=50, required=False,widget=forms.TextInput(attrs={'type': 'text'}))
    address = forms.CharField(max_length=50, required=False, widget=forms.TextInput(attrs={'type': 'text'}))
    phone = forms.CharField(max_length=15, required=False,widget=forms.TextInput(attrs={'type': 'text'}))
    class Meta:
        model = Customer
        fields = ['fullname', 'address', 'phone']

class ChangePasswordForm(forms.Form):
    current_password = forms.CharField(widget=forms.PasswordInput)
    new_password = forms.CharField(widget=forms.PasswordInput)
    confirm_new_password = forms.CharField(widget=forms.PasswordInput)
        
